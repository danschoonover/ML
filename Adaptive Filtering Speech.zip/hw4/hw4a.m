%adaptive HW3a
%% Create pink noise
clear all;
load pink.mat
X=pink(1001:3000)'; %pink
%X=randn(1,2000); %white
N = length(X);  % number of samples to synthesize
PWR=sum(X.^2)/length(X);
X=X/sqrt(PWR);
b=[1 zeros(1,9) -1]; a=[1 -1];
D=filter(b,a,X);

added_gaussian=randn(N,1).*sqrt(.1);
D = D+added_gaussian';
D=D/sqrt(sum(D.^2)/length(D));
clear added_gaussian pink a b;
%figure; plot(abs(fft(X)))
figure; hold on;  plot(D,'b');plot(X,'k'); title('X = black. D = blue')
%% Design and train LMS filter

M=5;

Wind=500;
Smax=3000; %max power of autocorr. function
mu=.1; %2*(2/(M*Smax)); %gradient descent step-size
w=.01*ones(M,1);%initialize weights @ .01

err=0;
msError=0;
u=zeros(M,1);%current input taps

[y,SE,R,P]=deal(zeros(size(Wind)),[],[],[]);

for n=M+1:Wind-(M+1) %train LMS on the window
    u=X(n-1:-1:n-M); %current inputs
    y(n)=w'*u'; %mimic system
    err=(D(n)-y(n)); %error signal
    
    w=w+mu*(u.*err)'; %weights update 
end

figure; hold on; plot(D(1:length(y)),'b'); plot(y,'k');

mserr = [];
for n=M+1:N-1     
    u=X(n-1:-1:n-M); %current inputs
    y(n)=w'*u'; %mimic system        
    mserr=[mserr; (D(n)-y(n)).^2]; %store error    
end

figure; hold on; plot(D,'b'); plot(y,'k'); plot(mserr,'r'); title(num2str(mean(mserr)));
%% PLOT CONTOUR

wMin=-4; wIter=.5; wMax=6;
perfSurf=zeros(10);
track=zeros(order,N);
for w1=wMin:wIter:wMax
   for w2=wMin:wIter:wMax
       y=filter([w1 w2],1,X);
       err=mean((y-D).^2);       
       perfSurf((round((w1-wMin)/wIter)+1),(round((w2-wMin)/wIter)+1))=err;
       track(locations,n)=
   end
end

ind=wMin:wIter:wMax;
figure; hold on; surf(ind,ind,perfSurf); 
xlabel('W1'); ylabel('W2');