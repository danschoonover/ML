%% Import and Prep speech
 clear all
[speech,fs]=wavread('speech.WAV');
N=numel(speech);
X=speech./sqrt(sum(speech.^2)/length(speech));

M=5; %order
Wind=500; %window length

%plot(X)
start=11500; %14900 'go', 2400 = 'we', 11500 = 'yeear'
Xtrain=X(start:start+Wind);
%soundsc(X)
soundsc(Xtrain,fs); %window = 'go'
%plot(Xtrain(1:Wind));

%find optimal mu
temp=xcorr(Xtrain);
top=toeplitz(temp(end/2:end/2+M));
[vecs,vals]=eigs(top);
mu=.5/vals(1,1);
%mu=.01;

w=0*ones(M,1);%initialize weights @ .01

err=0;
msError=0;
u=zeros(M,1);%current input taps
[y,SE,R,P]=deal([],[],[],[]);
D=[1;X]; 
D=D(1:end-1); trainerr=[];

for i=1:200
for n=M+1:Wind-(M+1) %train LMS on the window
    u=Xtrain(n-1:-1:n-M); %current inputs
    y(n)=w'*u; %mimic system
    err=(Xtrain(n)-y(n)); %error signal
    
    w=w+mu*(u.*err); %weights update 
    newerr(n)=err;
    trainerr=[trainerr, err];   
end
%  figure; hold on; plot(Xtrain,'b'); plot(y,'k'); plot(newerr,'r'); title(strcat('MSE = ',num2str(mean(newerr))));
%  pause;
%  close;
end

%figure; hold on; plot(Xtrain,'b'); plot(y(1:length(Xtrain)),'k'); plot(trainerr(end-length(Xtrain):end),'r');
%figure; hold on; plot(D(1:length(y)),'b'); plot(y,'k');

mserr = []; %Set it loose on all data, store SE
for n=M+1:N-1     
    u=X(n-1:-1:n-M); %current inputs
    y(n)=w'*u; %mimic system        
    mserr=[mserr; (D(n)-y(n)).^2]; %store error    
end
MSError=mean(mserr);
figure; hold on;  plot(y,'k'); plot(mserr,'r'); title(strcat('MSE = ',num2str(MSError), ' starting pnt.',num2str(start)));

% %% PLOT CONTOUR
% 
% wMin=-4; wIter=.5; wMax=6; % w= [1.4, -.5]
% perfSurf=zeros(10);
% track=zeros(M,N);
% for w1=wMin:wIter:wMax
%    for w2=wMin:wIter:wMax
%        y=filter([w1 w2],1,X);
%        err=mean((y-D).^2);       
%        perfSurf((round((w1-wMin)/wIter)+1),(round((w2-wMin)/wIter)+1))=err;
%        %track(locations,n)=
%    end
% end
% 
% ind=wMin:wIter:wMax;
% figure; hold on; surf(ind,ind,perfSurf); 
% xlabel('W1'); ylabel('W2');