function p3image
tic
global imlist ptr h images a timetrial ttimes;

figure(h); clf

% keyboard

ptr=ptr+1;

image(images.pics{imlist(ptr),1}); colormap(images.pics{imlist(ptr),2});

set(findobj('type', 'axes'), 'visible', 'off') % hides the legend's axes (legend border and background)

axis image; 
% truesize(h, [250 250]);%display image in original size/formatting:

newtime=toc(timetrial);

ttimes(imlist(ptr))=newtime;

if ptr==images.repeat%  ptr points to the current image
     stop(a); pause(.5);   clf; 
end
%PAUSES RATHER THAN TIMERS????  clf

toc
end