% function[]=vidtest()
% plots p3 target cartoon images with some period in between

clear all; close all; clc; delete(timerfindall);

cd ../..
addpath ANT
cd('p3sublim/p3sublim with pauses')
load chans;

chanstouse={'P3','PZ','P4','FZ'};
for i=1:length(chanstouse)
    chaninds(i)=find(strcmp(chanstouse(i),chans));
end

Sn=input('enter subject #');
%% get the ANT EEG system online
fs=256;

goAmp;
%% load pics

global imlist ptr h images a timeflash timetrial ttimes target fullscreen;

cd pics
list=ls;
for i=3:size(list,1)
    thispic=list(i,:);
    [im imap]=imread(thispic);
    images.pics{i-2,1}=im;
    images.pics{i-2,2}=imap;
end
cd ..
%% run exp
delete(timerfindall);
fullscreen = get(0,'ScreenSize'); %screen size for maximizing
% h=figure('Color', [1 1 1], 'MenuBar', 'none', 'ToolBar', 'none', 'Position',[0 0 fullscreen(3) fullscreen(4)]);
h=figure('Color', [1 1 1], 'MenuBar', 'none', 'ToolBar', 'none');

showims=4; %number of times to flash each image before ending a run
period=.13; %start high and optimize.
numtrials=10; %num of trials per target per session
dlps=500; %amount of data (in seconds) to acquire post stimulus

ttimes=zeros(showims*length(images.pics),1);%stores times from trial onset of target appearing

images.repeat=showims*size(images.pics,1);

%numsessions=1;
% for sess=1:numsessions  %ishandle(h)
tic
for target =1:length(images.pics)
    
    figure(h);
    [aa ab]=imread('Attention.gif');  image(aa); colormap(ab);
    set(findobj('type', 'axes'), 'visible', 'off') % hides the legend's axes (legend border and background)
    axis image; pause(1);
    image(images.pics{target,1}); colormap(images.pics{target,2});
    title('YOUR NEW TARGET');
    axis image; pause(1); clf; clc; pause(.1);
    
    for tr=1:numtrials
        
        ptr=0;
        imlist=[];
        
        for repeat=1:showims
            imlist=[imlist randperm(length(images.pics))];    %randomize image list
        end
        
        timetrial=tic;
        
        for imflash=1:length(imlist)
            
            begin=tic;
            
            image(images.pics{imlist(imflash),1}); colormap(images.pics{imlist(imflash),2});
            
            set(findobj('type', 'axes'), 'visible', 'off') % hides the legend's axes (legend border and background)
            
            axis image;
            ttimes(imflash)=toc(timetrial);
            
            %truesize(h, [250 250]);%display image in original size/formatting:
            elapsed=toc(begin);
            
            pause(period-elapsed);
            
        end
        pause(.5-period);
        
        Tgrab=toc(timetrial);

        temptrial{tr}.raw=getEEG(oDevice,Tgrab);
        temptrial{tr}.flashtimes=ttimes;
        temptrial{tr}.target=target;

        ttimes=zeros(length(images.pics),1);
        
    end  %tr
    
    EEG.rawexp{target}=temptrial;%store raw and averaged EEG
    
end    %target
toc
cd(strcat('EEG/S',num2str(Sn)));
save('EEG-plain','EEG');
cd ../..

% end %sess

%     %for each image, average 500ms after each flash
%     for flash=1:length(images.pics)
%         ued=[];
%         for trial=1:numtrials
%             ued=[];%grab this images' data, store in array
%         end
%         %average all data for this image
%         EEG.u=ued;
%         EEG.rawexp=temp;%store raw and averaged EEG
%     end
    
    %and do it again
%% Get user  feedback

% clc; disp('how well were you able to attend to the video while the images were flashing?');
% focus=input(' Enter number 1-10 (1 = poor, 10 = full concentration)');

%save EEG