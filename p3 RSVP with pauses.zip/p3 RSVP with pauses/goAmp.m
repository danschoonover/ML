%function[]=goAmp(fs)%warm up the amp
fs=256;

% oDevice = disconnect(sHost);% disconnect from server
oDevice = device('tmsi');% connect to server
% oDevice = connect(oDevice);
oDevice = fconnect(oDevice,fs); % 1024 is the requested sampling rate, this can be set by user
%% collect till no more zeros
hf = figure(1);

while ishandle(hf)
    temp=[];
    tempdat=getEEG(oDevice, 2);
    plot(tempdat(:,26)); %store thisTrial to cell array
%     axis([1 512 -1.6e-4 -1e-4])
    pause(.25);
end
clear tempdat
