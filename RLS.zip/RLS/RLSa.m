%% Creates a Recursive Least Squares filter 
% Applies a RLS filter on a noisy signal X, with desired signal D

clear all; close all; clc;

load pink.mat % load pink noise

X=pink(1001:3000)'; %pink

N = length(X);  % number of samples to synthesize

PWR=sum(X.^2)/length(X);

X=X/sqrt(PWR);
b=[1 zeros(1,9) -1]; a=[1 -1];
D=filter(b,a,X);

added_gaussian=randn(N,1).*sqrt(.1);
D = D+added_gaussian';
D=D/sqrt(sum(D.^2)/length(D));

clear added_gaussian pink a b;

figure; hold on;  plot(D,'b'); plot(X,'k'); legend('input', 'desired signal')
%% Design Recursive least squares filter (DCS' implementation)

lambda=.99;      %forgetting factor
M=15;            %model order

w=zeros(M,1); %initialize weights
error=zeros(length(X),1);
alph=.1; %choose from SNR of input
sigm=var(X); %
delt=sigm^2*(1-lambda)^alph;
Rinv=delt*eye(M);
weights=[];

for n=M:length(X)
    u=X(n:-1:n-M+1); %current tap input vector
    Xnew=X(1:n);
    y(n)=u*w;
    error(n)=D(n)-y(n);
    
    Zk=Rinv*u'; %kalman gain
    q=u*Zk;
    v=1/(1+q);
    nZk=v*Zk;
    
    w=w+error(n)*nZk;
    Rinv=Rinv-nZk*Zk';
    %weights=[weights w];
    
end

figure; hold on;  plot(D,'b');plot(y,'g'); plot(abs(error),'r');